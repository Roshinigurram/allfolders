﻿function GreetUser() {
    alert("Welcome to " + location.href);
}
